package com.example.finalproject.student_ui.sclub;

import androidx.lifecycle.ViewModel;

public class SclubViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}