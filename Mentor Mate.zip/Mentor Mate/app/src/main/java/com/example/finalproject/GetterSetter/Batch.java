package com.example.finalproject.GetterSetter;

public class Batch
{
    public String getBatch() {
        return Batch;
    }

    public void setBatch(String batch) {
        Batch = batch;
    }

    String Batch;
}
