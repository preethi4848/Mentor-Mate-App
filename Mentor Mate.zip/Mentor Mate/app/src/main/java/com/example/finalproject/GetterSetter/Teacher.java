package com.example.finalproject.GetterSetter;

public class Teacher
{
    String teacherId;
    String teacherName;
    String teacherEmail;
    String teachPassword;
    String teacherBranch;
    public String getTeacherId() {
        return teacherId;
    }

    public void setTeacherId(String teacherId) {
        this.teacherId = teacherId;
    }

    public String getTeacherName() {
        return teacherName;
    }

    public void setTeacherName(String teacherName) {
        this.teacherName = teacherName;
    }

    public String getTeacherEmail() {
        return teacherEmail;
    }

    public void setTeacherEmail(String teacherEmail) {
        this.teacherEmail = teacherEmail;
    }

    public String getTeachPassword() {
        return teachPassword;
    }

    public void setTeachPassword(String teachPassword) {
        this.teachPassword = teachPassword;
    }

    public String getTeacherBranch() {
        return teacherBranch;
    }

    public void setTeacherBranch(String teacherBranch) {
        this.teacherBranch = teacherBranch;
    }


}
