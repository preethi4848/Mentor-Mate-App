package com.example.finalproject.GetterSetter;

public class Student
{
    String Redg_No;
    String Name;
    String Password;
    String Batch;
    String Branch;
    String Semester;
    String Section;

    public String getMentorId() {
        return MentorId;
    }

    public void setMentorId(String mentorId) {
        MentorId = mentorId;
    }

    String MentorId;
    public String getRedg_No() {
        return Redg_No;
    }

    public void setRedg_No(String redg_No) {
        Redg_No = redg_No;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String password) {
        Password = password;
    }

    public String getBatch() {
        return Batch;
    }

    public void setBatch(String batch) {
        Batch = batch;
    }

    public String getBranch() {
        return Branch;
    }

    public void setBranch(String branch) {
        Branch = branch;
    }

    public String getSemester() {
        return Semester;
    }

    public void setSemester(String semester) {
        Semester = semester;
    }

    public String getSection() {
        return Section;
    }

    public void setSection(String section) {
        Section = section;
    }


}
