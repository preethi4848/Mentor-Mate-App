package com.example.finalproject.student_ui.ssocial;

import androidx.lifecycle.ViewModel;

public class SsocialViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}