package com.example.finalproject.teacher_ui.club;

import androidx.lifecycle.ViewModel;

public class ClubViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}